<?php 

$sql = mysqli_connect('localhost', 'root', '', 'nid_generator_db');

?>